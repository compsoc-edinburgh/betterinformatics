<?xml version="1.0" encoding="utf-8"?><rss version="2.0">
<channel>
<title>Learn You a Haskell for Great Good!</title>
<link>http://learnyouahaskell.com</link>
<description>Learn You a Haskell for Great Good! - news</description>
<pubDate>Mon, 19 Apr 2010 08:10:22 GMT</pubDate>
<language>en-us</language>

            <item>
        <title>newtypes and monoids!</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>a section on applicative functors is up, read it while it's hot!</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>new section called FUNCTORS REDUX up, applicatives and monoids coming up next!</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>added short little section on exceptions, gonna be more frequent with updates from nao on, i promise!!!</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>hey, i added a short section about bytestrings</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>i've been busy with school stuff, that's why new content hasn't been added for like a week. i'll have more time by the end of february though, so keep your eyes peeled!</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>another problem functionally solved! use haskell to find the shortest path from the airport to london!</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>new section on making a RPN calculator! check it out!!!</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>new section called "Making your own modules" has been added to the Modules chapter. is nise i like.</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
                <item>
        <title>there's an RSS feed now. w00t!</title>
        <link>http://learnyouahaskell.com/chapters</link>
        </item>
        </channel>
</rss>

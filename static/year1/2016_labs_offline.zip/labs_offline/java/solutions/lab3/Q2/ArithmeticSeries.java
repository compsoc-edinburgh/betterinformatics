public class ArithmeticSeries {

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int i = 0;
        int total = 0;
        while (i < n) {
            i += 1;
            total += i;
        }
        System.out.println(total);
    }

}

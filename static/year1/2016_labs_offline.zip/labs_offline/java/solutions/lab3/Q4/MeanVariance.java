public class MeanVariance {

    public static void main(String[] args) {
        int n = args.length;
        double[] dataset = new double[n];

        for (int i = 0; i < n; i++) {
            dataset[i] = Double.parseDouble(args[i]);
        }

        // Calculate mean:
        double mean = 0;
        for (int i = 0; i < n; i++) {
            mean = mean + dataset[i];
        }
        mean = mean / n;

        // Calculate variance:
        double ssd = 0;
        for (int i = 0; i < n; i++) {
            double d = dataset[i] - mean;
            ssd = ssd + (d * d);
        }
        ssd = ssd / n;

        System.out.println(mean);
        System.out.println(ssd);
    }
}

import java.util.ArrayList;

public class Dalek3 {

    private final ArrayList<String> sayings = new ArrayList<>();

    public void setSayings(String[] sayings) {
        for (int i=0; i<sayings.length; i++)
        this.sayings.add(sayings[i]);
    }

    public void speak() {
        String utterance;
        if (sayings.size() > 0) {
            int i = (int) (Math.random() * sayings.size());
            utterance = sayings.get(i);
        }
        else {
            utterance = "No utterances installed!";
        }
        System.out.println(utterance);

    }

    public void addSaying(String saying) {
        sayings.add(saying);        
    }

    public static void main(String[] args) {

        Dalek3 d1 = new Dalek3();
        String[] u1 = { 
            "Exterminate, Exterminate!", 
            "I obey!", 
            "Exterminate, annihilate, DESTROY!", 
            "You cannot escape.", 
            "Daleks do not feel fear.",
            "The Daleks must survive!" 
        };
        d1.setSayings(u1);

        System.out.println("\nDalek d1 says: ");
        for (int i = 0; i < 10; i++) {
            d1.speak();
        }

        System.out.println("\nDalek d2 says: ");
        Dalek3 d2 = new Dalek3();
        String[] u2 = { "I obey!" };
        d2.setSayings(u2);

        for (int i = 0; i < 10; i++) {
            d2.speak();
        }
    }

}

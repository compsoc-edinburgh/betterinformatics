import java.util.Arrays;

public class Tokenizer {

    private String[] tokens = {};

    public Tokenizer(String fname) {
        tokensFromFile(fname);
    }

    public Tokenizer() {
        // Do nothing
    }

    public String[] getTokens() {
        return tokens;
    }

    public int getNumberTokens() {
        return tokens.length;
    }

    /**
     * Split input on non-word characters. This throws away punctuation
     * characters.
     */
    public void tokenize(String str) {
        tokens = str.split("\\W+");
    }

    public void tokensFromFile(String fname) {
        In file = new In(fname);
        tokenize(file.readAll());
    }

    public static void main(String[] args) {

        String input = "this is some text\n and--here\tis $5.00; And 'more' text";

        Tokenizer tokenizer = new Tokenizer();
        tokenizer.tokenize(input);
        System.out.println(tokenizer.getNumberTokens());
        String[] tokens = tokenizer.getTokens();
        System.out.println(Arrays.toString(tokens));

    }

}

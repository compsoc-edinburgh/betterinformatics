public class Rectangle {

    private Point2DDouble topLeft;
    private Point2DDouble bottomRight;

    public Rectangle(Point2DDouble topLeft, Point2DDouble bottomRight) {
        this.topLeft = topLeft;
        this.bottomRight = bottomRight;
    }

    public Rectangle() {
        this(new Point2DDouble(0, 0), new Point2DDouble(1, 1));
    }

    public boolean isPointInside(Point2DDouble pt) {
        if (topLeft.getX() > pt.getX()) {
            return false;
        }
        if (bottomRight.getX() < pt.getX()) {
            return false;
        }

        if (topLeft.getY() > pt.getY()) {
            return false;
        }
        if (bottomRight.getY() < pt.getY()) {
            return false;
        }

        return true;
    }

}

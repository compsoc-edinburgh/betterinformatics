public class Interval {

    private double left, right;

    public Interval(double left, double right) {
        this.left = left;
        this.right = right;
    }

    public boolean doesContain(double item) {
        if (isEmpty()) {
            return false;
        }
        return (left < item && right > item);
    }

    public boolean isEmpty() {
        return left > right;
    }

    public boolean intersects(Interval other) {
        if (isEmpty() || other.isEmpty()) {
            return false;
        }

        if (left > other.right) {
            return false;
        }
        if (right < other.left) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        if (isEmpty()) {
            return "Interval: (EMPTY)";
        }
        return "Interval: [" + left + ", " + right + "]";
    }

}
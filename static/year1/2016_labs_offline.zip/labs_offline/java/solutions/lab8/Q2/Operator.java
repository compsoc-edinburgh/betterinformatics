/**
 * An enumeration class of boolean operators for Propositional Logic. These end
 * up being like constants.
 * 
 * @author Ewan Klein
 */
public enum Operator {

	AND {
		@Override
        public String toString() {
			return "&";
		}
	},

	OR {
		@Override
        public String toString() {
			return "|";
		}
	},

	IF {
		@Override
        public String toString() {
			return "->";
		}
	}

}

public class PropVar {

	private String propVar;
	
	public PropVar(String str) {
		this.propVar = str;
	}
	
	@Override
    public String toString() {
		return propVar;
	}
}

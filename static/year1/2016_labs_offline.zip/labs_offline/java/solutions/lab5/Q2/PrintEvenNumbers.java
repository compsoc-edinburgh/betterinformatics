public class PrintEvenNumbers {
    
    /**
     * Print all the even number between lowerBound and upperBound inclusive.
     * @param args array of input arguments. args[0] = lowerBound, args[1] = upperBound
     */
    public static void main(String args[]) {
        int lowerBound = Integer.parseInt(args[0]);
        int upperBound = Integer.parseInt(args[1]);
        if (lowerBound <= upperBound) {
            for (int i = lowerBound; i <= upperBound; i++) {
                if (i % 2 == 0) {
                    System.out.print(i + " ");
                }
            }
        }
        else {
            System.out.println(lowerBound + " cannot be greater than " + upperBound);
        }
    }
}

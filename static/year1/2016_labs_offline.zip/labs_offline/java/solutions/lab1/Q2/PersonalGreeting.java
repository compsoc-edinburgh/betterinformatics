public class PersonalGreeting {

    public static void main(String args[]) {
        String first_name = args[0];
        String last_name = args[1];
        System.out.println("Hello " + first_name + " " + last_name);
    }

}

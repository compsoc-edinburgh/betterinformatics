public class Multiplier {

    public static void main(String args[]) {
        int value1 = Integer.parseInt(args[0]);
        int value2 = Integer.parseInt(args[1]);
        int value3 = Integer.parseInt(args[2]);

        int product = value1 * value2 * value3;

        System.out.print(value1);
        System.out.print(" * ");
        System.out.print(value2);
        System.out.print(" * ");
        System.out.print(value3);
        System.out.print(" = ");
        System.out.print(product);
    }

}

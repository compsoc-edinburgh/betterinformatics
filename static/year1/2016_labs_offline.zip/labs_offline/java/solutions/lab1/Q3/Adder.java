public class Adder {

    public static void main(String args[]) {
        int value1 = Integer.parseInt(args[0]);
        int value2 = Integer.parseInt(args[1]);

        System.out.println(value1 + value2);
    }

}

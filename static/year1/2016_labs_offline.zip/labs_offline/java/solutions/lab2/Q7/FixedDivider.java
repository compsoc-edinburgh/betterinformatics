public class FixedDivider {

    public static void main(String args[]) {
        double numerator = Double.parseDouble(args[0]);
        double denominator = Double.parseDouble(args[1]);

        System.out.print(numerator / denominator);
    }

}

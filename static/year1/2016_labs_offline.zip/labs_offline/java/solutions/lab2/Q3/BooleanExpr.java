public class BooleanExpr {

    public static void main(String args[]) {

        boolean a = Boolean.parseBoolean(args[0]);
        boolean b = Boolean.parseBoolean(args[1]);

        boolean result = (!(a && b) && (a || b)) || ((a && b) || !(a || b));

        System.out.print("a: ");
        System.out.print(a);
        System.out.print("\nb: ");
        System.out.print(b);
        System.out.print("\nphi: ");
        System.out.print(result);
        System.out.print("\n");
    }

}

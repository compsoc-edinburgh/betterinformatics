public class Distance2 {

    public static void main(String args[]) {
        int value1 = Integer.parseInt(args[0]);
        int value2 = Integer.parseInt(args[1]);

        int distance = Math.abs(value2 - value1);
        System.out.println(distance);
    }

}

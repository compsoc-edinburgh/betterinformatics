public class SquaresLoopRange {

    public static void main(String[] args) {
        int lower = Integer.parseInt(args[0]);
        int upper = Integer.parseInt(args[1]);

        if (lower <= upper) {
            for (int i = lower; i <= upper; i++) {
                System.out.print(i * i + " ");
            }
            System.out.println();
        }
        else {
            System.out.println("Start-limit greater than stop-limit!");
        }

    }

}

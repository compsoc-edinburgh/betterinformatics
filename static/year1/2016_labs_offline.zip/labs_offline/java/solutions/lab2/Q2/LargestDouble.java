public class LargestDouble {

    public static void main(String args[]) {
        double value1 = Double.parseDouble(args[0]);
        double value2 = Double.parseDouble(args[1]);

        Double result = Math.max(value1, value2);
        System.out.print(result);
    }

}

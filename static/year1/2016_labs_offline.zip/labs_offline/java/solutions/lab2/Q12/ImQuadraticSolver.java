public class ImQuadraticSolver {

    // TODO update
    
    public static void main(String args[]) {
        double a = Double.parseDouble(args[0]);
        double b = Double.parseDouble(args[1]);
        double c = Double.parseDouble(args[2]);

        if (a == 0.0) {
            double solution = -c / b;
            System.out.println(solution);
        }
        else {
            double discriminant = b * b - 4 * a * c;
            if (discriminant < 0) {
                double solutionRealPart = (-1.0 * b) / (2 * a);
                double solutionImaginaryPart = Math.sqrt(Math.abs(discriminant)) / (2 * a);
                System.out.println(solutionRealPart + " + " + solutionImaginaryPart + "i");
                System.out.println(solutionRealPart + " - " + solutionImaginaryPart + "i");
            }
            else {
                double solution1 = (-1.0 * b + Math.sqrt(discriminant)) / (2 * a);
                double solution2 = (-1.0 * b - Math.sqrt(discriminant)) / (2 * a);
                System.out.println(solution1);
                System.out.println(solution2);
            }
        }
    }
}

package threads;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Simple threaded processor
 */
public class ThreadedProcessor {

    private static final long PROCESS_COUNT = 10;

    public static void main(String[] args) {
        long startTime = Calendar.getInstance().getTimeInMillis();
        List<Thread> threads = new ArrayList<>();
        
        // Launch the worker threads
        for (int i=0; i<PROCESS_COUNT; i++) {
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    CPUProcess.run();
                }
            };
            Thread thread = new Thread(runnable);
            threads.add(thread);
            thread.start();
        }
        
        // Wait for all threads to finish execution
        do {
            try {
                Thread.sleep(100);
            }
            catch (InterruptedException e) {
                // Not expecting to be interrupted
            }
            
            while (!threads.isEmpty()) {
                Thread thread = threads.get(0);
                if (!thread.isAlive()) {
                    threads.remove(thread);
                }
                else {
                    break;
                }
            }
        } while (!threads.isEmpty());
        
        long endTime = Calendar.getInstance().getTimeInMillis();
        long runtime = (endTime - startTime) / 1000;
        System.out.println("Total runtime: " + runtime + "s");
    }

}

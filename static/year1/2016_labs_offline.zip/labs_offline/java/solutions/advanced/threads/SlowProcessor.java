package threads;

import java.util.Calendar;

/**
 * Simple unthreaded processor.
 */
public class SlowProcessor {

    private static final long PROCESS_COUNT = 10;

    public static void main(String[] args) {
        long startTime = Calendar.getInstance().getTimeInMillis();

        for (int i=0; i<PROCESS_COUNT; i++) {
            CPUProcess.run();
        }
        
        long endTime = Calendar.getInstance().getTimeInMillis();
        long runtime = (endTime - startTime) / 1000;
        System.out.println("Total runtime: " + runtime + "s");
    }
}

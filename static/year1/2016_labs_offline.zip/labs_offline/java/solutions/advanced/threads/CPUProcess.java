package threads;

import java.util.Calendar;

/**
 * A simple worker process that uses up runtime for a given period of time
 */
public class CPUProcess {

    // Adjust this value to suit processor speed
    // The process should take at least 3 seconds to run, but not a huge amount more than 3 seconds.
    private static final long DIFFICULTY = 3000000000l;
    
    private static int startedProcessCount = 0;
    private static int completedProcessCount = 0;
    
    /**
     * Run worker process
     */
    public static void run() {
        int currentProcess = startedProcessCount++;
        System.out.println("Starting process " + currentProcess);
        long startTime = Calendar.getInstance().getTimeInMillis();
        
        // Do some random processing
        boolean bool = false;
        for (long i=0; i<DIFFICULTY; i++) {
            bool = !bool;
        }
        
        long endTime = Calendar.getInstance().getTimeInMillis();
        long runtime = endTime - startTime;
        System.out.println("Ending process " + currentProcess + ", time taken " + runtime + "ms");
        completedProcessCount++;
    }
    
    public static int getStartedProcessCount() {
        return startedProcessCount;
    }

    public static int getCompletedProcessCount() {
        return completedProcessCount;
    }

    public static void resetProcessCounts() {
        startedProcessCount = 0;
        completedProcessCount = 0;
    }
    
}

package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilmDatabase {
    
    private static final String DATABASE_URI = "jdbc:hsqldb:file:film";

    public static String viewTable(Connection connection, String tableName) {

        String[] columnNames = listAllColumnsForTable(connection, tableName);
        String[][] tableData = getTableData(connection, tableName, columnNames);
        
        StringBuilder result = new StringBuilder();
        result.append(getRowString(columnNames)).append("\n");
        for (String[] row : tableData) {
            result.append(getRowString(row)).append("\n");

        }
        return result.toString();
    }

    private static String getRowString(String[] cells) {
        StringBuilder result = new StringBuilder();
        boolean firstCell = true;
        for (String cell : cells) {
            if (!firstCell) {
                result.append(", ");
            }
            firstCell = false;
            result.append(cell);
        }
        return result.toString();
    }

    public static String[] listAllTables(Connection connection) {
        List<String> tables = new ArrayList<>();
        try {
            ResultSet resultSet = connection.getMetaData().getTables(null, "PUBLIC", null, null);
            try {
                while (resultSet.next()) {
                    tables.add(resultSet.getString(3));
                }
            }
            finally {
                resultSet.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return tables.toArray(new String[tables.size()]);
    }

    public static String[] listAllColumnsForTable(Connection connection, String tableName) {
        List<String> columns = new ArrayList<>();
        try {
            ResultSet resultSet = connection.getMetaData().getColumns(null, "PUBLIC", tableName, null);
            try {
                while (resultSet.next()) {
                    columns.add(resultSet.getString(4));
                }
            }
            finally {
                resultSet.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return columns.toArray(new String[columns.size()]);
    }

    public static String[][] getTableData(Connection connection, String tableName, String[] columnNames) {
        List<String[]> rows = new ArrayList<>();
        try {
            StringBuilder query = new StringBuilder();
            query.append("select ");
            boolean firstColumn = true;
            for (String columnName : columnNames) {
                if (!firstColumn) {
                    query.append(", ");
                }
                firstColumn = false;
                query.append("\"").append(columnName).append("\"");
            }
            query.append(" from \"").append(tableName).append("\"");

            
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query.toString());

            try {
                while (resultSet.next()) {
                    String[] row = new String[columnNames.length];
                    for (int i=0; i < columnNames.length; i++) {
                        row[i] = resultSet.getString(i+1);
                    }
                    rows.add(row);
                }
            }
            finally {
                resultSet.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return rows.toArray(new String[rows.size()][]);
    }

    public static String[] getActorById(Connection connection, String actorId) {
        String[] result = null;
        try {
            PreparedStatement statement = connection.prepareStatement("select * from \"Actor\" where \"actorId\" = ?");
            statement.setString(1, actorId);
            ResultSet resultSet = statement.executeQuery();
            try {
                if (resultSet.next()) {
                    result = new String[4];
                    for (int i=0; i < 4; i++) {
                        result[i] = resultSet.getString(i+1);
                    }
                }
            }
            finally {
                resultSet.close();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        return result;
    }

    public static boolean addNewActor(Connection connection, String actorId, String actorName, String nationality, int age) {
        if (getActorById(connection, actorId) != null) {
            return false;
        }
        
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO \"Actor\" (\"actorId\",\"name\",\"nationality\",\"age\") VALUES (?,?,?,?)");
            try {
                statement.setString(1, actorId);
                statement.setString(2, actorName);
                statement.setString(3, nationality);
                statement.setInt(4, age);
                statement.executeUpdate();
            }
            finally {
                statement.close();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        
        return true;
    }

    public static Connection getDatabaseConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URI, "SA", "");
    }

    public static void main(String[] args) {
        try {
            Class.forName("org.hsqldb.jdbcDriver");
            Connection connection = getDatabaseConnection();
            System.out.println(connection.getMetaData().getDriverName());
            System.out.println(connection.getMetaData().getDriverVersion());

            System.out.println(Arrays.toString(listAllTables(connection)));
            System.out.println(viewTable(connection, "Film"));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}

package localization;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Locale.Builder;
import java.util.ResourceBundle;

public class LocalInfo {

    public static void main(String[] args) {
        String language = null;
        String region = null;
        if (args.length > 0) {
            language = args[0];
        }
        if (args.length > 1) {
            region = args[1];
        }
        System.out.println(getLocalInfo(language, region, Calendar.getInstance()));
    }

    public static String getLocalInfo(String language, String region, Calendar currentTime) {
        Locale locale = Locale.getDefault();
        if (language != null) {
            Builder builder = new Builder();
            builder.setLanguage(language);
            if (region != null) {
                builder.setRegion(region);
            }
            locale = builder.build();
        }
                
        ResourceBundle labels = ResourceBundle.getBundle("localeBundle", locale);
        
        StringBuilder result = new StringBuilder();
        result.append(labels.getString("welcomeMessage") + "\n");
        result.append(labels.getString("localeMessage") + locale.toString() + "\n");
        result.append(labels.getString("dateFormatMessage") + DateFormat.getDateInstance(DateFormat.LONG, locale).format(currentTime.getTime()) + "\n");
        result.append(labels.getString("timeFormatMessage") + DateFormat.getTimeInstance(DateFormat.LONG, locale).format(currentTime.getTime()) + "\n");
        result.append(labels.getString("numberFormatMessage") + NumberFormat.getNumberInstance(locale).format(1234567.8901) + "\n");
        result.append(labels.getString("currencyFormatMessage") + NumberFormat.getCurrencyInstance(locale).format(1234567.89) + "\n");
        return result.toString();
    }

}

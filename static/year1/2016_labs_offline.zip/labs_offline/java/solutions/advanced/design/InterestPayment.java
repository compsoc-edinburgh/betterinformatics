package design;

import java.math.BigDecimal;
import java.util.Date;

public class InterestPayment extends AbstractTransaction {

    public InterestPayment(Account targetAccount, Date date, BigDecimal amount) {
        super(targetAccount, date, amount);
    }
    
    @Override
    public TransactionType getType() {
        return TransactionType.INTEREST_PAYMENT;
    }

}

package design;

import java.math.BigDecimal;
import java.util.Date;

public class Withdrawal extends AbstractTransaction {

    public Withdrawal(Account targetAccount, Date date, BigDecimal amount) {
        super(targetAccount, date, amount);
    }
    
    @Override
    public TransactionType getType() {
        return TransactionType.WITHDRAWAL;
    }
}

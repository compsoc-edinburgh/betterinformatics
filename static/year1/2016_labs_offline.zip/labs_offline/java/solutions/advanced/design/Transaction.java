package design;

import java.math.BigDecimal;
import java.util.Date;

public interface Transaction {

    public static enum TransactionType {
        DEPOSIT,
        WITHDRAWAL,
        TRANSFER,
        INTEREST_PAYMENT,
    }

    public TransactionType getType();
    
    public Date getDate();
    
    public BigDecimal getAmount();
    
    public Account getTargetAccount();
    
}

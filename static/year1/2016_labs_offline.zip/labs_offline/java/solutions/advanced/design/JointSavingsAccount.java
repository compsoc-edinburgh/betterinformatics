package design;

import design.Transaction.TransactionType;


public class JointSavingsAccount extends AbstractAccount implements JointAccount {

    private final String secondAccountHolder;
    
    public JointSavingsAccount(String accountNumber, String accountHolder, String secondAccountHolder) {
        super(accountNumber, accountHolder);
        this.secondAccountHolder = secondAccountHolder;
    }
    
    @Override
    public String getSecondAccountHolder() {
        return secondAccountHolder;
    }

    @Override
    public void addTransaction(Transaction transaction) {
        if (transaction.getType() != TransactionType.INTEREST_PAYMENT && transaction.getType() != TransactionType.TRANSFER) {
            throw new RuntimeException("Invalid transaction type for account");
        }
        super.addTransaction(transaction);
    }

    @Override
    protected String getAccountDescription() {
        return "Joint savings account";
    }

    @Override
    public String toString() {
        return getAccountDescription() + " " + getAccountNumber() + " : " + getAccountHolder() + ", " + getSecondAccountHolder() + " : £" + getAccountBalance();
    }
}

package design;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import design.Transaction.TransactionType;

/**
 * Abstract superclass of accounts containing the common features.
 */
public abstract class AbstractAccount implements Account {

    private final String accountNumber;
    private final String accountHolder;
    private final List<Transaction> transactions = new ArrayList<>();

    public AbstractAccount(String accountNumber, String accountHolder) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
    }

    @Override
    public String getAccountHolder() {
        return accountHolder;
    }

    @Override
    public String getAccountNumber() {
        return accountNumber;
    }

    @Override
    public BigDecimal getAccountBalance() {
        BigDecimal result = BigDecimal.ZERO;
        for (Transaction transaction : transactions) {
            switch (transaction.getType()) {
            case DEPOSIT:
            case INTEREST_PAYMENT:
                result = result.add(transaction.getAmount());
                break;

            case WITHDRAWAL:
                result = result.subtract(transaction.getAmount());
                break;

            case TRANSFER:
                if (transaction.getTargetAccount() == this) {
                    result = result.add(transaction.getAmount());
                }
                else {
                    result = result.subtract(transaction.getAmount());
                }
                break;
            }

        }
        return result;
    }

    @Override
    public void addTransaction(Transaction transaction) {
        if (transaction.getType() == TransactionType.TRANSFER) {
            Transfer transfer = (Transfer) transaction;
            if (transfer.getSourceAccount() != this && transfer.getTargetAccount() != this) {
                throw new RuntimeException("Unknown account");
            }
        }
        else {
            if (transaction.getTargetAccount() != this) {
                throw new RuntimeException("Unknown account");
            }
        }

        transactions.add(transaction);
    }

    @Override
    public String printTransactions() {
        StringBuilder builder = new StringBuilder();
        for (Transaction transaction : transactions) {
            builder.append(transaction).append("\n");
        }
        return builder.toString();
    }

    @Override
    public String toString() {
        return getAccountDescription() + " " + accountNumber + " : " + accountHolder + " : £" + getAccountBalance();
    }

    protected abstract String getAccountDescription();

}

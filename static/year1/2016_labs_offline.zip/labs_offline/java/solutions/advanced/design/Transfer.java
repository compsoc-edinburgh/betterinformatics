package design;

import java.math.BigDecimal;
import java.util.Date;

public class Transfer extends AbstractTransaction {

    private final Account sourceAccount;
    
    public Transfer(Account sourceAccount, Account targetAccount, Date date, BigDecimal amount) {
        super(targetAccount, date, amount);
        this.sourceAccount = sourceAccount;
    }
    
    @Override
    public TransactionType getType() {
        return TransactionType.TRANSFER;
    }
    

    public Account getSourceAccount() {
        return sourceAccount;
    }

    
    @Override
    public String toString() {
        return DATE_FORMAT.format(getDate()) + " : " + getType() + 
                " (from account " + getSourceAccount().getAccountNumber() +
                " to account " + getTargetAccount().getAccountNumber() +
                ") : £"+ getAmount();
    }

}

package design;

import design.Transaction.TransactionType;

public class CurrentAccount extends AbstractAccount {

    public CurrentAccount(String accountNumber, String accountHolder) {
        super(accountNumber, accountHolder);
    }
    
    @Override
    public void addTransaction(Transaction transaction) {
        if (transaction.getType() == TransactionType.INTEREST_PAYMENT) {
            throw new RuntimeException("Invalid transaction type for account");
        }
        super.addTransaction(transaction);
    }

    @Override
    protected String getAccountDescription() {
        return "Current account";
    }

}

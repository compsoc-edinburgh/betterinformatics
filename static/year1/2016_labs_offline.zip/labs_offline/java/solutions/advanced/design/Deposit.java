package design;

import java.math.BigDecimal;
import java.util.Date;

public class Deposit extends AbstractTransaction {

    public Deposit(Account targetAccount, Date date, BigDecimal amount) {
        super(targetAccount, date, amount);
    }
    
    @Override
    public TransactionType getType() {
        return TransactionType.DEPOSIT;
    }

}

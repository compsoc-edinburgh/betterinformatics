package design;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Abstract superclass of transactions containing the common features.
 */
public abstract class AbstractTransaction implements Transaction {

    protected static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
    
    private final Account targetAccount;
    private final Date date;
    private final BigDecimal amount;
    
    public AbstractTransaction(Account targetAccount, Date date, BigDecimal amount) {
        this.targetAccount = targetAccount;
        this.date = date;
        this.amount = amount;
    }
    
    @Override
    public Date getDate() {
        return date;
    }

    @Override
    public BigDecimal getAmount() {
        return amount;
    }

    @Override
    public Account getTargetAccount() {
        return targetAccount;
    }
    
    @Override
    public String toString() {
        return DATE_FORMAT.format(date) + " : " + getType() + " : £"+ amount;
    }

}

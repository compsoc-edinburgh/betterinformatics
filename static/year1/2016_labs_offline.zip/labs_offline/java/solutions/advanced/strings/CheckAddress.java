package strings;

import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckAddress {

    private static final Pattern VALID_POSTCODE = 
            Pattern.compile("[a-zA-Z]{1,2}(([0-9]{1,2})|([0-9][a-zA-Z])) [0-9][a-zA-Z]{2}");
    private static final Pattern CANONICAL_POSTCODE = 
            Pattern.compile("[A-Z]{1,2}(([0-9]{1,2})|([0-9][A-Z])) [0-9][A-Z]{2}");
    private static final Pattern ADDRESS_LINE_SEPARATION = Pattern.compile("(,)|(\\v+)");

    
    public static boolean isValidPostcode(String postcode) {
        return VALID_POSTCODE.matcher(postcode).matches();
    }
    
    public static boolean isCanonicalPostcode(String postcode) {
        return CANONICAL_POSTCODE.matcher(postcode).matches();
    }
    
    public static String getCanonicalPostcode(String postcode) {
        if (!isValidPostcode(postcode)) {
            return "";
        }
        return postcode.toUpperCase();
    }

    private static String[] getAddressLines(String address, boolean splitPostcode) {
        Matcher matcher = ADDRESS_LINE_SEPARATION.matcher(address);
        String allLines = matcher.replaceAll("\n");
        String[] lines = allLines.split("\n");
        String[] result = lines;
        if (splitPostcode) {
            StringTokenizer tokens = new StringTokenizer(lines[lines.length - 1], " ");
            int tokenCount = tokens.countTokens();
            if (tokenCount > 2) {
                result = new String[lines.length + 1];
                System.arraycopy(lines, 0, result, 0, lines.length - 1);
                String city = "";
                for (int i = 0; i < tokenCount - 2; i++) {
                    city = " " + tokens.nextToken();
                }
                result[result.length - 2] = city;
                result[result.length - 1] = tokens.nextToken() + " " + tokens.nextToken();
            }
        }
        return trimAndRemoveBlankLines(result);
    }

    private static String[] trimAndRemoveBlankLines(String[] lines) {
        int target = 0;
        for (int i=0; i<lines.length; i++) {
            String line = lines[i].trim();
            if (!line.isEmpty()) {
                lines[target++] = line;
            }
        }
        if (target < lines.length) {
            String[] newResult = new String[target];
            System.arraycopy(lines, 0, newResult, 0, target);
            return newResult;
        }
        return lines;
    }
    
    public static boolean isValidAddress(String address) {
        String[] lines = getAddressLines(address, true);
        return lines.length > 2 && isValidPostcode(lines[lines.length - 1]);
    }
    
    public static boolean isCanonicalAddress(String address) {
        String[] lines = getAddressLines(address, false);
        if (lines.length <= 2) {
            return false;
        }
        String city = lines[lines.length - 2];
        String postcode = lines[lines.length - 1];
        return isCanonicalPostcode(postcode) && city.equals(city.toUpperCase());
    }
    
    public static String getCanonicalAddress(String address) {
        if (!isValidAddress(address)) {
            return "";
        }
        String[] lines = getAddressLines(address, true);
        lines[lines.length - 2] = lines[lines.length - 2].toUpperCase();
        lines[lines.length - 1] = lines[lines.length - 1].toUpperCase();
        StringBuilder result = new StringBuilder();
        for (String line : lines) {
            result.append(line).append("\n");
        }
        return result.toString().trim();
    }
    
}

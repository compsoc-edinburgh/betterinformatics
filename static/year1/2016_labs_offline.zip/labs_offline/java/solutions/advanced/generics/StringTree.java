package generics;

import java.util.ArrayList;
import java.util.List;

public class StringTree {

    private final List<StringTree> children = new ArrayList<>();
    private final String value;
    
    public StringTree(String value) {
        this.value = value;
    }
    
    public void addChild(StringTree child) {
        children.add(child);
    }

    public List<String> getAllValues(int depth) {
        List<String> result = new ArrayList<>();
        if (depth < 0) {
            throw new IllegalArgumentException();
        }
        
        if (depth == 0) {
            result.add(value);
        }
        else {
            for (StringTree node : children) {
                result.addAll(node.getAllValues(depth - 1));
            }
        }
        return result;
    }
    
    @Override
    public String toString() {
        return "'" + value + "' => " + children.toString();
    }
}

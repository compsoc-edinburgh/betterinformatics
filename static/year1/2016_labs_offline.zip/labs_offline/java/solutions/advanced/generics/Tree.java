package generics;

import java.util.ArrayList;
import java.util.List;

public class Tree<S> {

    private final List<Tree<S>> children = new ArrayList<>();
    private final S value;
    
    public Tree(S value) {
        this.value = value;
    }
    
    public void addChild(Tree<S> child) {
        children.add(child);
    }

    public List<S> getAllValues(int depth) {
        List<S> result = new ArrayList<>();
        if (depth < 0) {
            throw new IllegalArgumentException();
        }
        
        if (depth == 0) {
            result.add(value);
        }
        else {
            for (Tree<S> node : children) {
                result.addAll(node.getAllValues(depth - 1));
            }
        }
        return result;
    }
    
    @Override
    public String toString() {
        return "'" + value + "' => " + children.toString();
    }

}

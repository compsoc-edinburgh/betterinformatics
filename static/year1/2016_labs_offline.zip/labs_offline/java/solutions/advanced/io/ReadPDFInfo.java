package io;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class ReadPDFInfo {

    private static final int STARTXREF_BUFFER_SIZE = 32;
    private static final int TRAILER_BUFFER_SIZE = 200;
    private static final int INFO_BUFFER_SIZE = 400;

    private static final String TAG_CREATION_DATE = "CreationDate";
    private static final String TAG_CREATOR = "Creator";
    private static final String TAG_PRODUCER = "Producer";
    private static final String TAG_SUBJECT = "Subject";
    private static final String TAG_AUTHOR = "Author";
    private static final String TAG_TITLE = "Title";
    private static final String TAG_INFO = "/Info";
    private static final String TAG_TRAILER = "trailer";
    private static final String TAG_EOF = "%%EOF";
    private static final String TAG_STARTXREF = "startxref";
    

    public static void main(String[] args) throws IOException {
        // File file = new File(args[0]);
        File file = new File("TestDocument.pdf");
        String result = readPDFInfo(file);
        System.out.println(result);
    }

    public static String readPDFInfo(File file) throws IOException {
        SeekableByteChannel channel = Files.newByteChannel(file.toPath(), StandardOpenOption.READ);
        
        long xrefIndex = getXrefIndex(channel);
        long[] xrefs = getXrefs(channel, xrefIndex);

        long infoIndex  = getInfoIndex(channel, xrefs);
        Map<String, String> infoFieldsMap = getInfoFieldsMap(channel, infoIndex);
        
        StringBuilder builder = new StringBuilder();
        builder.append("Title: ").append(infoFieldsMap.get(TAG_TITLE)).append("\n");
        builder.append("Subject: ").append(infoFieldsMap.get(TAG_SUBJECT)).append("\n");
        builder.append("Author: ").append(infoFieldsMap.get(TAG_AUTHOR)).append("\n");
        builder.append("Producer: ").append(infoFieldsMap.get(TAG_PRODUCER)).append("\n");
        builder.append("Creator: ").append(infoFieldsMap.get(TAG_CREATOR)).append("\n");
        builder.append("CreationDate: ").append(infoFieldsMap.get(TAG_CREATION_DATE)).append("\n");
        return builder.toString();
    }

    private static Map<String, String> getInfoFieldsMap(SeekableByteChannel channel, long infoIndex) throws IOException {
        channel.position(infoIndex);
        ByteBuffer buffer = ByteBuffer.allocate(INFO_BUFFER_SIZE);
        channel.read(buffer);
        
        String string = new String(buffer.array());
        int index = string.indexOf("endobj");
        if (index == -1) {
            throw new RuntimeException();
        }
        string = string.substring(0, index - 1);
        
        Map<String, String> result = new HashMap<>();
        result.put(TAG_TITLE, getField(string, TAG_TITLE));
        result.put(TAG_AUTHOR, getField(string, TAG_AUTHOR));
        result.put(TAG_SUBJECT, getField(string, TAG_SUBJECT));
        result.put(TAG_PRODUCER, getField(string, TAG_PRODUCER));
        result.put(TAG_CREATOR, getField(string, TAG_CREATOR));
        result.put(TAG_CREATION_DATE, getField(string, TAG_CREATION_DATE));
        return result;
    }

    private static String getField(String string, String key) {
        int index = string.indexOf("/" + key);
        if (index == -1) {
            return "";
        }
        String substring = string.substring(index + key.length() + 2);
        if (substring.charAt(0) == '(') {
            index = substring.indexOf(')');
            if (index == -1) {
                throw new RuntimeException();
            }
            substring = substring.substring(1, index);
            return substring;
        }
        throw new RuntimeException();
    }

    private static long getInfoIndex(SeekableByteChannel channel, long[] xrefs) throws IOException {
        channel.position(channel.size() - TRAILER_BUFFER_SIZE);
        ByteBuffer buffer = ByteBuffer.allocate(TRAILER_BUFFER_SIZE);
        channel.read(buffer);
        
        String string = new String(buffer.array());
        int index = string.indexOf(TAG_TRAILER);
        if (index == -1) {
            throw new RuntimeException();
        }
        string = string.substring(index);
        index = string.indexOf(TAG_INFO);
        if (index == -1) {
            throw new RuntimeException();
        }
        string = string.substring(index + TAG_INFO.length() + 1);
        StringTokenizer tokens = new StringTokenizer(string, " ");
        int infoReference = Integer.parseInt(tokens.nextToken());
        
        long result = xrefs[infoReference];
        return result;
    }

    private static long[] getXrefs(SeekableByteChannel channel, long xrefIndex) throws IOException {
        channel.position(xrefIndex);
        ByteBuffer buffer = ByteBuffer.allocate((int) (channel.size() - xrefIndex));
        channel.read(buffer);
        
        String string = new String(buffer.array());
        String[] lines = string.split("\n");
        String countLine = lines[1];
        StringTokenizer tokens = new StringTokenizer(countLine, " ");
        tokens.nextToken();
        int objectCount = Integer.parseInt(tokens.nextToken());
        
        long[] result = new long[objectCount];
        for (int i=0; i<result.length; i++) {
            tokens = new StringTokenizer(lines[2+i], " ");
            result[i] = Long.parseLong(tokens.nextToken());
        }
        return result;
    }

    private static long getXrefIndex(SeekableByteChannel channel) throws IOException {
        channel.position(channel.size() - STARTXREF_BUFFER_SIZE);
        ByteBuffer buffer = ByteBuffer.allocate(STARTXREF_BUFFER_SIZE);
        channel.read(buffer);
        
        String string = new String(buffer.array());
        int index = string.indexOf(TAG_STARTXREF);
        if (index == -1) {
            throw new RuntimeException();
        }
        string = string.substring(index + TAG_STARTXREF.length() + 1);
        index = string.indexOf(TAG_EOF);
        if (index == -1) {
            throw new RuntimeException();
        }
        string = string.substring(0, index - 1);
        long result = Long.parseLong(string);
        return result;
    }

}

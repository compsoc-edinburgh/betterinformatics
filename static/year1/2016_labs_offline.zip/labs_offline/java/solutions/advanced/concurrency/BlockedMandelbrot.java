package concurrency;

import java.awt.Color;
import java.awt.geom.Rectangle2D;

public class BlockedMandelbrot extends BasicMandelbrot {
    
    // Assume IMAGE_SIZE is multiple of BLOCK_SIZE
    public static final int BLOCK_SIZE   = 40;


    @Override
    public void run() {
        for (int i = 0; i < IMAGE_SIZE; i += BLOCK_SIZE) {
            for (int j = 0; j < IMAGE_SIZE; j += BLOCK_SIZE) {
                double xBlockStart = X_START + SCALE * i;
                double yBlockStart = Y_START + SCALE * j;
                plotBlock(xBlockStart, yBlockStart, BLOCK_SIZE, SCALE, ITERATION_MAX);
            }
        }

    }

    protected void plotBlock(double xStart, double yStart, int blockSize, double scale, int iterationMax) {
        for (int i = 0; i < blockSize; i++) {
            for (int j = 0; j < blockSize; j++) {
                double x0 = xStart + scale * i;
                double y0 = yStart + scale * j;
                int gray = iterationMax - mandelbrot(x0, y0, iterationMax);
                Color color = new Color(gray, gray, gray);
                
                graphics.setColor(color);
                graphics.fill(new Rectangle2D.Double(x0, y0, scale, scale));
                frame.repaint();
            }
        }
    }
    
    public static void main(String[] args)  {
        new BlockedMandelbrot().run();
    }

}

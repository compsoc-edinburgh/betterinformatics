package concurrency;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

public class ThreadedMandelbrot extends BlockedMandelbrot {

    @Override
    public void run() {
        List<Thread> threads = new ArrayList<>();

        // Launch the worker threads
        for (int i = 0; i < IMAGE_SIZE; i += BLOCK_SIZE) {
            for (int j = 0; j < IMAGE_SIZE; j += BLOCK_SIZE) {
                final double xBlockStart = X_START + SCALE * i;
                final double yBlockStart = Y_START + SCALE * j;
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        plotBlock(xBlockStart, yBlockStart, BLOCK_SIZE, SCALE, ITERATION_MAX);
                    }
                };
                Thread thread = new Thread(runnable);
                threads.add(thread);
                thread.start();
            }
        }

        // Wait for all threads to finish execution
        do {
            try {
                Thread.sleep(100);
            }
            catch (InterruptedException e) {
                // Not expecting to be interrupted
            }

            while (!threads.isEmpty()) {
                Thread thread = threads.get(0);
                if (!thread.isAlive()) {
                    threads.remove(thread);
                }
                else {
                    break;
                }
            }
        } while (!threads.isEmpty());
    }

    @Override
    protected void plotBlock(double xStart, double yStart, int blockSize, double scale, int iterationMax) {
        for (int i = 0; i < blockSize; i++) {
            for (int j = 0; j < blockSize; j++) {
                double x0 = xStart + scale * i;
                double y0 = yStart + scale * j;
                int gray = iterationMax - mandelbrot(x0, y0, iterationMax);
                Color color = new Color(gray, gray, gray);
                synchronized (graphics) {
                    graphics.setColor(color);
                    graphics.fill(new Rectangle2D.Double(x0, y0, SCALE, SCALE));
                }
                frame.repaint();
            }
        }
    }

    public static void main(String[] args) {
        new ThreadedMandelbrot().run();
    }
}
